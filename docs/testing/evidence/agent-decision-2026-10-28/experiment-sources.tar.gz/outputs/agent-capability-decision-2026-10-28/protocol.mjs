import {readFileSync,writeFileSync} from 'node:fs';
import {randomUUID,createHash} from 'node:crypto';
import {platform,observedProvider} from '../../workers/ai-worker/src/live-tests/acceptance-common.ts';
const source=JSON.parse(readFileSync(new URL('../agent-routing-review-2026-10-28/route-ab.json',import.meta.url),'utf8'));
const selected=['memory','two-bubbles','cause','proof','accept-task','social','negated','simple'];
const cases=source.cases.filter(c=>selected.includes(c.id));const route=platform('agent_turn'),records=[];
const jobs=cases.flatMap(c=>[0,1].flatMap(repeat=>(repeat%2?['instructions','input_system']:['input_system','instructions']).map(arm=>({c,repeat,arm}))));
writeFileSync(new URL('./protocol-manifest.json',import.meta.url),JSON.stringify({prompt:source.prompts.compact,cases,scope:'Only placement of the identical system policy changes. Sequential within this script; concurrent capability diagnostic elsewhere. Latency is not an isolated provider benchmark. No new few-shot examples or policy changes.'},null,2));
for(const {c,repeat,arm} of jobs){
 const wire=[],record={id:c.id,expected:c.expected,repeat,arm,wire},start=performance.now();records.push(record);
 const provider=observedProvider(route,randomUUID(),wire,undefined,undefined,undefined,b=>{
  if(arm==='instructions'){
   b.instructions=b.input.filter(m=>m.role==='system').map(m=>m.content).join('\n\n');
   b.input=b.input.filter(m=>m.role!=='system');
  }
  record.request=b;record.requestHash=createHash('sha256').update(JSON.stringify(b)).digest('hex');
 });
 try{
  const r=await provider.chatCompletion([{role:'system',content:source.prompts.compact},...c.history.map(([role,content])=>({role,content})),{role:'user',content:JSON.stringify({text:c.text,state:c.state})}],{disableThinking:true,reasoningEffort:'none',temperature:0,responseFormat:'json_object'},AbortSignal.timeout(20000));
  record.response=r.content;record.decision=JSON.parse(r.content);record.pass=record.decision.route===c.expected;
 }catch(e){record.error=e instanceof Error?e.name:'unknown';record.pass=false;}
 record.elapsedMs=Math.round(performance.now()-start);
 writeFileSync(new URL('./protocol-results.json',import.meta.url),JSON.stringify({records},null,2));
 console.log(JSON.stringify({id:c.id,arm,repeat,pass:record.pass,ms:record.elapsedMs}));
}
