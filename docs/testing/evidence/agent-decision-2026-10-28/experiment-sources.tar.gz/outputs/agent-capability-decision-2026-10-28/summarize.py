from pathlib import Path
import json,statistics,math,hashlib,subprocess
p=Path('outputs/agent-capability-decision-2026-10-28'); out=Path('docs/testing/evidence/agent-decision-2026-10-28')
names=['screen','control','quality','protocol','routing-holdout','parallel-chat','review','contract','contract-real']
def quantile(xs):
 xs=sorted(xs);return {'n':len(xs),'p50':statistics.median(xs),'p95NearestRank':xs[math.ceil(.95*len(xs))-1],'max':max(xs)} if xs else None
all_data={}; summary={}; total=0
for name in names:
 rows=json.loads((p/(name+'-results.json')).read_text())['records'];assert all('elapsedMs' in r for r in rows)
 clean=[]
 for r in rows:
  c={k:v for k,v in r.items() if k not in ['payloads','requests','request','steps','semanticReview']}
  c['providerRequests']=len(r.get('payloads',r.get('requests',[r.get('request')]) or []));total+=c['providerRequests']
  c['steps']=[{k:v for k,v in s.items() if k in ['content','toolCalls','receipts','elapsedMs','firstTextMs']} for s in r.get('steps',[])]
  clean.append(c)
 all_data[name]=clean
 group={}
 for arm in sorted(set(r.get('arm',r.get('mode','review')) for r in rows)):
  rs=[r for r in rows if r.get('arm',r.get('mode','review'))==arm]
  d={'trials':len(rs),'durationMs':quantile([r['elapsedMs'] for r in rs]),'errors':sum(bool(r.get('error')) for r in rs)}
  if 'structuralPass' in rs[0]:
   d['structuralPass']=sum(r['structuralPass'] for r in rs)
   d['normalTask']={'passed':sum(r['structuralPass'] for r in rs if r['kind'] not in ['chat','quality','failed']),'n':sum(r['kind'] not in ['chat','quality','failed'] for r in rs)}
  if 'pass' in rs[0]:d['matched']=sum(r['pass'] for r in rs)
  if name=='routing-holdout':
   d['wrongFast']={'n':sum(r['expected']=='work' for r in rs),'count':sum(r['expected']=='work' and r.get('decision',{}).get('path')=='chat' for r in rs)}
   d['unavailable']=sum(r.get('decision',{}).get('path') not in ['chat','work'] for r in rs)
  if name=='parallel-chat':d.update(firstPublishedMs=quantile([r['firstPublishedMs'] for r in rs if r.get('firstPublishedMs') is not None]),fallback=sum(r['route']=='fallback' for r in rs))
  group[arm]=d
 summary[name]=group
m=json.loads((p/'screen-manifest.json').read_text())
summary['integrity']={'headAtSummary':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'frozenSelectedSourcesUnchanged':{f:hashlib.sha256(Path(f).read_bytes()).hexdigest()==h for f,h in m['sources'].items()},'providerRequestAttempts':total,'trialCount':sum(len(v) for v in all_data.values()),'scope':'Provider-level synthetic experiments plus real pure document transformer; not production HTTP/DB/client acceptance. Counts include cancellation/timeouts. Structural pass does not certify semantics.'}
(out/'results.compact.json').write_text(json.dumps(all_data,ensure_ascii=False,indent=2))
(out/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
(p/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
print(json.dumps(summary,ensure_ascii=False,indent=2))
