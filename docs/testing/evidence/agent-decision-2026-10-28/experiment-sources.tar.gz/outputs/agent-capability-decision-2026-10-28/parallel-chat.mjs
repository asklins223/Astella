import {readFileSync,writeFileSync} from 'node:fs';
import {randomUUID,createHash} from 'node:crypto';
import {platform,observedProvider} from '../../workers/ai-worker/src/live-tests/acceptance-common.ts';
import {resolveAllCompanionAgentTools} from '../../packages/shared/src/index.ts';
import {buildCompanionPersonaMessages} from '../../workers/ai-worker/src/handlers/turn/companion-dialogue-content.ts';
import {resolveCompanionPersonaContext} from '../../workers/ai-worker/src/handlers/memory/companion-identity-context.ts';
import {companionDirectInterpretation,companionDirectGuidance} from '../../workers/ai-worker/src/handlers/turn/companion-entry-mode.ts';
import {assembleCompanionStepRequest,companionStepPolicyText} from '../../workers/ai-worker/src/handlers/agent/companion-agent-step-assembly.ts';
const dir=new URL('./',import.meta.url),prev=JSON.parse(readFileSync(new URL('routing-holdout-manifest.json',dir))),route=platform('agent_turn');
const policy=prev.policy+'\n以下是不同语境的判例：\n'+JSON.stringify(prev.examples.map(([input,path])=>({input,output:{path}})));
const cases=[{id:'tea',text:'泡了一壶茶，今晚就这样慢慢待着吧。'},{id:'rain',text:'雨停了，窗台上的叶子亮晶晶的。'},{id:'correction',history:[['user','我去超市转了一圈。'],['assistant','买到菜了吗？']],text:'没买东西，就随便走走。'},{id:'quote',text:'同事今天说“全删了重做”，我一听就头大。只是来吐槽两句。'},{id:'switch',history:[['assistant','需要把这条整理成笔记吗？']],text:'不了，先陪我聊聊。今晚的月亮好圆。'}];
const jobs=cases.flatMap((c,i)=>i%2?[{c,mode:'parallel'},{c,mode:'serial'}]:[{c,mode:'serial'},{c,mode:'parallel'}]);
const tools=resolveAllCompanionAgentTools('full',{visionEnabled:false}).map(({name,description,parameters})=>({name,description,parameters}));
const manifest={cases,policy,tools,jobs:jobs.map(({c,mode})=>({id:c.id,mode})),routerDeadlineMs:1200,scope:'Actual paired serial/parallel provider requests, new synthetic chat wording. Router failure/late/work cancels private fast draft then starts high; no model-side tools executed. Public timing measured when both route and text available, after leading voice tags. Provider-level experiment, no network/client/queue SLO.'};
writeFileSync(new URL('parallel-chat-manifest.json',dir),JSON.stringify(manifest,null,2));const records=[];
for(const {c,mode} of jobs){
 const start=performance.now(),record={id:c.id,mode,wire:[],requests:[],published:[]};records.push(record);const now=()=>Math.round(performance.now()-start);
 let release=false,buffer='',firstFastBodyMs=null,fastCalls=[];const draftAbort=new AbortController();
 const contentBody=s=>s.replace(/^(?:\s*\[[a-z_-]+\]\s*)*/,'').trim();
 const publish=()=>{const b=contentBody(buffer);if(release&&b&&!b.startsWith('[')&&/\p{L}/u.test(b)&&record.firstPublishedMs==null){record.firstPublishedMs=now();record.firstPublishedText=b.slice(0,100);}};
 const provider=(type)=>observedProvider(route,randomUUID(),record.wire,undefined,undefined,undefined,b=>{if(type==='router'){b.instructions=b.input.filter(m=>m.role==='system').map(m=>m.content).join('\n\n');b.input=b.input.filter(m=>m.role!=='system');}record.requests.push({type,sha256:createHash('sha256').update(JSON.stringify(b)).digest('hex'),body:b});});
 async function classify(){const t=now();try{const r=await provider('router').chatCompletion([{role:'system',content:policy},{role:'user',content:JSON.stringify({history:c.history??[],text:c.text})}],{disableThinking:true,reasoningEffort:'none',temperature:0,responseFormat:'json_object'},AbortSignal.timeout(1200));const path=JSON.parse(r.content).path;if(!['chat','work'].includes(path))throw Error('invalid route');record.route=path;}catch(e){record.route='fallback';record.routeError=e.name;}record.routeMs=now()-t;record.routeDoneMs=now();return record.route;}
 async function generate(effort,signal){const p=provider(effort),history=(c.history??[]).map(([role,text])=>({role,text})),base=buildCompanionPersonaMessages({userText:c.text,recentMessages:history,pageContext:null,petProfile:resolveCompanionPersonaContext(null)});const request=assembleCompanionStepRequest({turnPolicy:String(base[0].content),runtimePolicy:companionStepPolicyText({permissionLevel:'full',toolCount:tools.length,stepBudget:Infinity,finalAnswerOnly:false,attentionIntent:'question',offeredToolNames:tools.map(t=>t.name),writingAnnotation:false,completeNoteReply:false}),executionGuidance:companionDirectGuidance('direct_thinking'),attention:companionDirectInterpretation(createHash('sha256').update(c.text).digest('hex')),messages:base.slice(1),currentUserText:c.text,tools,toolChoice:'auto',disableThinking:effort==='none',reasoningEffort:effort,provider:p,temperature:0.3});
  try{const r=await p.chatCompletionStream([],{nativeAgentRequest:request,responseFormat:'text'},signal,d=>{buffer+=d;const b=contentBody(buffer);if(b&&!b.startsWith('[')&&/\p{L}/u.test(b))firstFastBodyMs??=now();publish();});fastCalls=r.toolCalls??[];record.toolCalls=fastCalls;record.final=r.content;record.finishedViaTool=false;if(!record.final&&fastCalls.length===1&&fastCalls[0].name==='companion_finish'){record.final=fastCalls[0].arguments.text;buffer=record.final;publish();record.finishedViaTool=true;}record.needsToolExecution=fastCalls.length>0&&!record.finishedViaTool;record.complete=!record.needsToolExecution;return r;}
  catch(e){record[effort==='none'?'draftError':'qualityError']=e.name;return null;}
 }
 const routePromise=classify();let draft;
 if(mode==='parallel')draft=generate('none',AbortSignal.any([draftAbort.signal,AbortSignal.timeout(45000)]));
 const path=await routePromise;
 if(path==='chat'){release=true;publish();if(mode==='serial')draft=generate('none',AbortSignal.timeout(45000));await draft;}
 else{draftAbort.abort();if(draft)await draft;buffer='';release=true;record.final='';record.firstPublishedMs=null;record.firstPublishedText=null;await generate('high',AbortSignal.timeout(60000));}
 record.firstBodyAvailableMs=firstFastBodyMs;record.elapsedMs=now();writeFileSync(new URL('parallel-chat-results.json',dir),JSON.stringify({records},null,2));console.log(JSON.stringify({id:c.id,mode,route:record.route,routeMs:record.routeMs,first:record.firstPublishedMs,ms:record.elapsedMs,complete:record.complete}));
}
